﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Movies.Models;

namespace Movies.Context
{
    public class MovieDBContext:DbContext
    { 
        public MovieDBContext(DbContextOptions<MovieDBContext> options) : base(options)
    {
            
    }
        public DbSet<Movie> Movie { get; set; }
    }
}
