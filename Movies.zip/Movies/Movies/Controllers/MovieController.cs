﻿using Microsoft.AspNetCore.Mvc;
using Movies.Context;
using Movies.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Movies.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : Controller
    {
        private static List<Movie> movies = new List<Movie>
        {
            new Movie() { Id=0,Name="DDLJ",Language="Hindi"}
        };

        private MovieDBContext _movieDBContext;
        public MovieController(MovieDBContext movieDBContext)
        {
            _movieDBContext = movieDBContext;
        }

         [HttpGet]
            public IEnumerable<Movie> Get()
            {
            return _movieDBContext.Movie.ToList();
            }
        [HttpPost]
        public void AddMovie([FromBody] Movie movie)
        {
            try
            {
                _movieDBContext.Movie.Add(movie);
                _movieDBContext.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        [HttpPut("id")]
        public void Update(int id,[FromBody] Movie movie)
        {
            var data = _movieDBContext.Movie.FirstOrDefault(x => x.Id == id);
            if (data != null)
            {
                data.Name = movie.Name;
                data.Language = movie.Language;
                _movieDBContext.SaveChanges();
            }
        }

        [HttpDelete]
        public void Delete(Movie movie)
        {
            _movieDBContext.Movie.Remove(movie);
            _movieDBContext.SaveChanges();
        }
    }
}
